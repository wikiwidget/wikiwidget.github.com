function loaded() {
}

function processRequest(search_term) {
    req = new XMLHttpRequest();
    
    url = "http://en.wikipedia.org/wiki/" + search_term;
    req.open("GET", url ,false);
    req.send(null);
    
    response = req.responseText;

    if (response.indexOf("Wikipedia does not have an") > -1) {
        output = '<p><b>' + search_term + '</b></b>';
        output = output + '<p>Wikipedia does not have an article with that exact name.</p>';
    } else {
        
        // css_start = response.indexOf('@import') + 9;
        // css_end = response.indexOf('.css') + 4;
        // css = response.substring(css_start, css_end);
        // css = "http://en.wikipedia.org" + css;
        
        // start = response.indexOf("<!-- start content -->");
        start = response.indexOf("<p>");
        end = response.indexOf("<!-- end content -->");
        output = response.substring(start, end);
        while (output.indexOf("/wiki/") > -1) {
            output = output.replace("/wiki/", "javascript:processRequest(\'");
            output = output.replace( '\" title', "')\"  title" );
        }
//        output = '<h1>' + search_term + '</h1>' + output;
        
    //    var stripped = output.replace(/(<([^>]+)>)/ig,"");
    }
    if (output.length < 20) {
        output = '<p><b>There seems to be a connection problem.</b></p>';
    }
    
    document.getElementById('content').innerHTML = output;
    
    calculateAndShowThumb(document.getElementById('content'));
}
