/*
* English
* Translated by: Your Name Here
*/


var localizedStrings = new Array;

localizedStrings["en"] 
    = "en";  //Wikipedia language code
localizedStrings["There was a problem connecting to the wikipedia server."]
    = "There was a problem connecting to the wikipedia server.";

localizedStrings["<b>Please enter a Wikipedia language code</b> in the preference panel of this widget.  These are the letters (usually 2, sometimes 3 or more) found in the Wikipedia URL for your language: htt://XX.wikipedia.org, where XX is the language code.  Here are some common codes:"]
    = "<b>Please enter a Wikipedia language code</b> in the preference panel of this widget.  These are the letters (usually 2, sometimes 3 or more) found in the Wikipedia URL for your language: htt://XX.wikipedia.org, where XX is the language code.  Here are some common codes:";

localizedStrings["Language code:"]
    = "Language code:";
localizedStrings["Other:"]
    = "Other:";
localizedStrings["Max cache age:"]
    = "Max cache age:";
localizedStrings["Empty Cache"]
    = "Empty Cache";
localizedStrings["minute(s)"]
    = "minute(s)";
localizedStrings["Check for updates:"]
    = "Check for updates:";
localizedStrings["update available"]
    = "update available";

localizedStrings["Color:"]
    = "Color:";
localizedStrings["Blue"]
    = "Blue";
localizedStrings["Green"]
    = "Green";
localizedStrings["Grey"]
    = "Grey";
localizedStrings["Orange"]
    = "Orange";
localizedStrings["Red"]
    = "Red";

localizedStrings["Done"]
    = "Done";