var langcode;
var flipper;

var searchTerm;

if (typeof(langcode) == "undefined") {
    langcode = 'en';
}
function loaded() {
    flipper = new Fader(document.getElementById('flip'), null, 500);
//    progressIndicator = new Fader(document.getElementById('progress'), null, 500);
    
//    createGenericButton (document.getElementById('doneButton'), 'Done', showFront, 67);

//    if (window.widget) {
//        window.widget.onhide = onHide;
//        window.widget.onshow = onShow;
//    }
}

function showBackside(event) {
	if (window.widget) {
		window.widget.prepareForTransition("ToBack");
	}
    document.getElementById('fliprollie').style.display='none';
    document.getElementById('front').style.display='none';
    document.getElementById('parentDiv').style.display='none';
    document.getElementById('searchBar').style.display='none';
    document.getElementById('wikiLink').style.display='none';
    document.getElementById('randomLink').style.display='none';
    document.getElementById('back').style.display='block';
    document.getElementById('doneButton').src = "Images/done.png";

    document.getElementById('languageField').value = langcode;

	if (window.widget) {
		setTimeout("window.widget.performTransition()", 0);
	}
}	

function showFront(event) {
	if (window.widget) {
		window.widget.prepareForTransition("ToFront");
	}
    document.getElementById('back').style.display='none';
    
    document.getElementById('front').style.display='block';
    document.getElementById('parentDiv').style.display='block';
    document.getElementById('wikiLink').style.display='block';
    document.getElementById('randomLink').style.display='block';
    document.getElementById('searchBar').style.display='block';
    
    setLanguage(document.getElementById('languageField').value);
	if (window.widget) {
		setTimeout("window.widget.performTransition()", 0);
	}
}

function openInBrowser() {
    if (document.getElementById('searchInput').value.length > 0) {
        searchTerm = document.getElementById('searchInput').value;
    }
        
    wikiUrl = 'http://' + langcode + '.wikipedia.org/wiki/' + searchTerm;

    widget.openURL(wikiUrl);
}

function setLanguage(language) {
    langcode = language;
}


function processRequest(input) {

    searchTerm = input;
    req = new XMLHttpRequest();
    
    if (typeof(langcode) == "undefined") {
        langcode = 'en';
    }
    
    url = "http://" + langcode + ".wikipedia.org/wiki/" + searchTerm;
    req.open("GET", url ,false);
    req.send(null);
    
    response = req.responseText;

    if (response.indexOf("Wikipedia does not have an") > -1) {
        output = '<p><b>' + searchTerm + '</b></p>';
        output = output + '<p>Wikipedia does not have an article with that exact name.</p>';
    } else {
        
        // css_start = response.indexOf('@import') + 9;
        // css_end = response.indexOf('.css') + 4;
        // css = response.substring(css_start, css_end);
        // css = "http://en.wikipedia.org" + css;
        
        // start = response.indexOf("<!-- start content -->");
        start = response.indexOf("<p>");
        if (start < 0) {
            start = response.indexOf("start content") + 17;
        }
        end = response.indexOf("<!-- end content -->");
        output = response.substring(start, end);
        while (output.indexOf("/wiki/") > -1) {
            output = output.replace("/wiki/", "javascript:processRequest(\'");
            output = output.replace( '\" title', "')\"  title" );
        }
        
        //output.replace('[<a href= (anything but gt) >', '[<a href="widget.openURL(anythingbutgt);" >');
        //  replace with '[<a href="widget.openURL(anythingbutgt);" >'   
        
    //    var stripped = output.replace(/(<([^>]+)>)/ig,"");
    }
    if (output.length < 20) {
        output = '<p><b>There seems to be a connection problem.</b></p>';
    } else if (langcode.length < 2) {
        output = "<p><b>Please enter a 2 letter Wikipedia language code</b> in the preference panel of this widget.  These are the two letters found in the Wikipedia URL for your language: htt://XX.wikipedia.org, where XX is the language code.  Here are some common codes:</p><ul><li>English - en</li><li>Deutsch - de</li><li>Japanese - ja</li><li>Français - fr</li><li>Svenska - sv</li><li>Polski - pl</li><li>Nederlands - nl</li><li>Español - es</li><li>Italiano - it</li><li>Português - it</li></ul><p>The only exception to this rule is 'simple English,' the code for which is 'simple'";
    }
    
    document.getElementById('content').innerHTML = output;
    
    calculateAndShowThumb(document.getElementById('content'));
}


